#----------------------------------------------------------------------------#
# Imports
#----------------------------------------------------------------------------#

from flask import Flask, render_template, request, redirect, url_for, flash, send_file, session
from flask_sqlalchemy import SQLAlchemy
from werkzeug.utils import secure_filename
import logging
from logging import Formatter, FileHandler
from forms import *
from extensions import db,app, upload_folder
from models import Profile, User
import os

#----------------------------------------------------------------------------#
# App Config.
#----------------------------------------------------------------------------#



# Automatically tear down SQLAlchemy.

@app.teardown_request
def shutdown_session(exception=None):
    db.session.remove()


# Login required decorator.

# def login_required(test):
#     @wraps(test)
#     def wrap(*args, **kwargs):
#         if 'logged_in' in request.session:
#             return test(*args, **kwargs)
#         else:
#             flash('You need to login first.')
#             return redirect(url_for('login'))
#     return wrap

#----------------------------------------------------------------------------#
# Controllers.
#----------------------------------------------------------------------------#


@app.route('/')
def home():
    return render_template('pages/placeholder.home.html')

@app.route('/search')
def search():
    users = db.session.query(Profile).all()
    return render_template('pages/placeholder.search.html',users=users)

@app.route('/edit',methods=['POST', 'GET'])
def edit():
    form = EditProfileForm(request.form)
    if request.method == 'POST' and form.validate():
        file_data = request.files[form.pdf.name]
        filename = secure_filename(file_data.filename)
        if filename == '':
            flash('No file selected!')
            return redirect(url_for('edit'))
        file_data.save(os.path.join(app.config['UPLOAD_FOLDER'],filename))
        profile = Profile(form.name.data, form.university.data, form.field.data, filename)
        db.session.add(profile)
        db.session.commit()
        return redirect(url_for('home'))
    return render_template('pages/editprofile.html', form=form)

@app.route('/login', methods=['GET','POST'])
def login():
    form = LoginForm(request.form)
    if request.method == 'POST' and form.validate():
        name = str(form.name.data)
        result = db.session.query(User).filter(User.name == name).first()
        if not result:
            flash('Wrong credidentals.')
            return redirect(url_for('login'))
        elif form.password.data == result.password:
            session['username'] = result.name
            session['signed_in'] = True
            flash('Login Success!')
            return redirect(url_for('home'))
        else:
            flash('Wrong credidentals.')
            return redirect(url_for('login'))
    elif not form.validate() and request.method == 'POST':
        print('#'*10,form.errors)
    return render_template('forms/login.html', form=form)

@app.route('/logout', methods=['GET'])
def logout():
    session.clear()
    session['signed_in'] = False
    return redirect(url_for('home'))

@app.route('/register', methods=['POST','GET'])
def register():
    form = RegisterForm(request.form)
    if request.method == "POST" and form.validate():
        user = User(form.name.data, form.password.data, form.email.data)
        db.session.add(user)
        db.session.commit()
        return redirect(url_for('register'))
    else:
        return render_template('forms/register.html', form=form)

@app.route('/uploads/<filename>', methods=['GET'])
def download(filename):
    file_path = upload_folder + '/' + filename  
    return send_file(file_path, as_attachment=True, attachment_filename='')

@app.route('/forgot')
def forgot():
    form = ForgotForm(request.form)
    return render_template('forms/forgot.html', form=form)

# Error handlers.


@app.errorhandler(500)
def internal_error(error):
    #db_session.rollback()
    return render_template('errors/500.html'), 500


@app.errorhandler(404)
def not_found_error(error):
    return render_template('errors/404.html'), 404

if not app.debug:
    file_handler = FileHandler('error.log')
    file_handler.setFormatter(
        Formatter('%(asctime)s %(levelname)s: %(message)s [in %(pathname)s:%(lineno)d]')
    )
    app.logger.setLevel(logging.INFO)
    file_handler.setLevel(logging.INFO)
    app.logger.addHandler(file_handler)
    app.logger.info('errors')

#----------------------------------------------------------------------------#
# Launch.
#----------------------------------------------------------------------------#

# Default port:
if __name__ == '__main__':
    app.run()

# Or specify port manually:
'''
if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5000))
    app.run(host='0.0.0.0', port=port)
'''
