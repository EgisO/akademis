from flask import Flask
from flask_sqlalchemy import SQLAlchemy
import os

base = os.getcwd()

upload_folder =  os.path.join(base,'uploads') 

app = Flask(__name__)
app.config.from_object('config')
app.config['UPLOAD_FOLDER'] = upload_folder
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024
db = SQLAlchemy(app)

SESSION_TYPE = 'redis'
app.secret_key = "kenandogulu"