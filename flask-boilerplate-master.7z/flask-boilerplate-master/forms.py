from flask_wtf import Form
from wtforms import TextField, PasswordField, FileField
from wtforms.validators import DataRequired, EqualTo, Length

# Set your classes here.


class RegisterForm(Form):
    name = TextField(
        'Username', validators=[DataRequired(), Length(min=6, max=25)]
    )
    email = TextField(
        'Email', validators=[DataRequired(), Length(min=6, max=40)]
    )
    password = PasswordField(
        'Password', validators=[DataRequired(), Length(min=6, max=40)]
    )
    confirm = PasswordField(
        'Repeat Password',
        [DataRequired(),
        EqualTo('password', message='Passwords must match')]
    )


class LoginForm(Form):
    name = TextField('Username', [DataRequired()])
    password = PasswordField('Password', [DataRequired()])


class ForgotForm(Form):
    email = TextField(
        'Email', validators=[DataRequired(), Length(min=6, max=40)]
    )

class EditProfileForm(Form):
    name = TextField(
        'Your Name', validators=[DataRequired(), Length(min=5, max=50)]
    )

    university = TextField(
        'Your University'
    )

    field = TextField(
        'Your field', validators=[DataRequired()]
    )

    pdf = FileField(
        'Your CV'
    )