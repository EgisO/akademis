import os

asasd = os.path.abspath(os.path.dirname(__file__)) + '\\uploads'

print(asasd)

