#!/usr/bin/env python
import os
from flask import *
from app import *

os.environ['PYTHONINSPECT'] = 'True'
